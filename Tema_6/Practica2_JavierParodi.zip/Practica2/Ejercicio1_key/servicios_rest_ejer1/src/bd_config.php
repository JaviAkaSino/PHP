<?php
	//CTES 
	define("SERVIDOR_BD","localhost");
	define("USUARIO_BD","jose");
	define("CLAVE_BD","josefa");
	define("NOMBRE_BD","bd_tienda");

	

?>
